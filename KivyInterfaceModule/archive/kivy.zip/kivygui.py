import os
#os.chdir("D:/Книги//Мои//Python//Articles//Articles//KivyGUI")
os.chdir("C://Work//Python//Articles//KivyInterfaceModule//")

import kivy

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.properties import StringProperty
from kivy.uix.recycleview import RecycleView
from kivy.uix.popup import Popup


'''
1. the left pane should contain text inputs for the from-date and to-date;
        a button that downloads the data from the internet; a button that gets
        the data from the database and a button that stores the downloaded data
        into the database.
'''

class MessageBox(Popup):
    '''
    This should be a generic messagebox - for now. It should be able to print
    any desired text, however.
    '''
    title = StringProperty()
    message = StringProperty()

class MainWindow(BoxLayout):
    '''
    This defines the main window. The main window should have three parts: 
        1. a left pane with buttons and text inputs;
        2. a central pane where certain text output should be displayed;
        3. a right pane with buttons for working with the central pane
        
    Uses horizontal box layout to contain the three panes
    '''
    pass

class LeftPane(BoxLayout):
    '''
    The left pane contains a text input for the start date; a text input for the
    end date; and three buttons. Button 1 downloads the data for the given period
    from the internet; Button 2 gets the data from the database; Button 3 stores
    any unstored data into the database.
    '''
    pass

class CentralPane(BoxLayout):
    '''
    The central pane has two text output sub-panes, both containing some text.
    The first is an article title; the second - its respective date.
    
    The central pane should be Recycle View.
    '''
    pass

class RightPane(BoxLayout):
    '''
    The right pane contains three buttons: 
        Button 1 assigns a "keep" flag to a selected item in the central pane;
        Button 2 assings a "discard" flag to a selected item in the central pane;
        Button 3 opens a selected item in a separate window.
    '''
    pass

class KivyGUIApp(App):
    '''
    This is the main application.
    '''
    
    def build(self):
        main_window = MainWindow()
        main_window.add_widget(LeftPane())
        main_window.add_widget(CentralPane())
        main_window.add_widget(RightPane())
        return main_window
    
    def message_box(self, title, message):
        '''
        This method handles the pop-up for all panes.
        
        Parameters:
            title: string; the title for the message box
            message: string; the message of the message box
        '''
        p = MessageBox()
        p.title = title
        p.message = message
        p.open() 
        print('test press: ', title, message)
    
kvapp = KivyGUIApp()
kvapp.run()