'''
Code used from the official example on kivy.ogr
RecycleView - full implementation:
    https://kivy.org/docs/_modules/kivy/uix/recycleview.html
    

#'''
import os
#os.chdir("D:/Книги//Мои//Python//Articles//Articles//KivyInterfaceModule")
os.chdir("C://Work//Python//Articles//KivyInterfaceModule//")

import kivy

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.properties import StringProperty
from kivy.uix.recycleview import RecycleView
from kivy.uix.popup import Popup
from kivy.uix.recycleview import RecycleView
from kivy.uix.recycleview.views import RecycleDataViewBehavior
from kivy.uix.button import Button
from kivy.uix.recycleboxlayout import RecycleBoxLayout
from kivy.uix.behaviors import FocusBehavior
from kivy.uix.recycleview.layout import LayoutSelectionBehavior
from kivy.properties import ListProperty, StringProperty, ObjectProperty, BooleanProperty


'''
1. the left pane should contain text inputs for the from-date and to-date;
        a button that downloads the data from the internet; a button that gets
        the data from the database and a button that stores the downloaded data
        into the database.
'''

class MessageBox(Popup):
    '''
    This should be a generic messagebox - for now. It should be able to print
    any desired text, however.
    '''
    title = StringProperty()
    message = StringProperty()


class SelectableRecycleBoxLayout(LayoutSelectionBehavior, RecycleBoxLayout):
    '''
    This should create a box layout to the recycle box and add layout selection
    behaviour options...?
    '''
    

class SelectableLabel(RecycleDataViewBehavior, Label):
    '''
    This should implement a label that can be selected (via the  Recycle... parent)
    in the view. 
    '''
    index = None
    selected = BooleanProperty(False)
    selectable = BooleanProperty(True)
    
    def refresh_view_attrs(self, rv, index, data):
        '''
        This method should handle what happens with the View when a label is selected
        '''
        self.index = index
        return super(SelectableLabel, self).refresh_view_attrs(rv, index, data)
    
    def on_touch_down(self, touch):
        '''
        Handles what happens when a label is pressed
        '''
        if super(SelectableLabel, self).on_touch_down(touch):
            return True
        if self.collide_point(*touch.pos) and self.selectable:
            return self.parent.select_with_touch(self.index, touch)
        
    def apply_selection(self, rv, index, is_selected):
        '''
        Respond to the selection of items in the view... somehow.
        '''
        self.selected = is_selected
        if is_selected:
            print("Something is selected. {0}".format(rv.data[index]))
        else:
            print("Selection removed from: {0}".format(rv.data[index]))
            


class MainWindow(BoxLayout):
    '''
    This defines the main window. The main window should have three parts: 
        1. a left pane with buttons and text inputs;
        2. a central pane where certain text output should be displayed;
        3. a right pane with buttons for working with the central pane
        
    Uses horizontal box layout to contain the three panes
    '''
    pass

class LeftPane(BoxLayout):
    '''
    The left pane contains a text input for the start date; a text input for the
    end date; and three buttons. Button 1 downloads the data for the given period
    from the internet; Button 2 gets the data from the database; Button 3 stores
    any unstored data into the database.
    '''
    pass

class CentralPane(RecycleView):
    '''
    The central pane has two text output sub-panes, both containing some text.
    The first is an article title; the second - its respective date.
    
    The central pane should be Recycle View.
    '''
#    rv_layout = ObjectProperty(None)
    
    def __init__(self, data, **kwargs):
        super(CentralPane, self).__init__(**kwargs)
        self.data = data

class RightPane(BoxLayout):
    '''
    The right pane contains three buttons: 
        Button 1 assigns a "keep" flag to a selected item in the central pane;
        Button 2 assings a "discard" flag to a selected item in the central pane;
        Button 3 opens a selected item in a separate window.
    '''
    pass

class KivyGUIApp(App):
    '''
    This is the main application.
    '''
    
    data = [{'text': str(x)} for x in range(100)]
    title = "random"
    
    
    def build(self):
        main_window = MainWindow()
        main_window.add_widget(LeftPane())
        main_window.add_widget(CentralPane(data=data))
        main_window.add_widget(RightPane())
        return main_window
    
    
    title, message = "title download", "message download"
    def message_box(self, title, message):
        '''
        This method handles the pop-up for all panes.
        
        Parameters:
            title: string; the title for the message box
            message: string; the message of the message box
        '''
        p = MessageBox()
        p.title = title
        p.message = message
        p.open() 
        print('test press: ', title, message)

data = [{'text': str(x)} for x in range(100)]
kvapp = KivyGUIApp()
kvapp.run()